import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { NavigationComponent } from './navigation/navigation.component';
import { MainComponent } from './main/main.component';
import { SingerComponent } from './singer/singer.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { SongsComponent } from './songs/songs.component';
import { LoginComponent } from './login/login.component';
import { SearchEngineComponent } from './search-engine/search-engine.component';
import { TimelineComponent } from './timeline/timeline.component';
import { AudioComponent } from './audio/audio.component';
@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    MainComponent,
    SingerComponent,
    SongsComponent,
    LoginComponent,
    SearchEngineComponent,
    TimelineComponent,
    AudioComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot([]),
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [
    AppComponent,
    NavigationComponent,
    MainComponent,
    SingerComponent,
    SongsComponent,
    LoginComponent,
    SearchEngineComponent,
    TimelineComponent
  ],
})
export class AppModule {}
