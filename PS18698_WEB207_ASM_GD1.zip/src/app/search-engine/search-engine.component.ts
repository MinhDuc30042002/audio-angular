import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-engine',
  templateUrl: './search-engine.component.html',
  styleUrls: ['./search-engine.component.css']
})
export class SearchEngineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  onBack(){
    history.back()
  }


  onGo(){
    history.go(1)
  }
}
