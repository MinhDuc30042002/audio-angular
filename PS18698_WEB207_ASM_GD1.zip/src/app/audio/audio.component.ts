import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-audio',
  templateUrl: './audio.component.html',
  styleUrls: ['./audio.component.css'],
})
export class AudioComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  Pause() {
    const buttonPlay = document.getElementById('ion-play');

    buttonPlay?.addEventListener('click', () => {
      buttonPlay.id = 'ion-pause'
      buttonPlay.className = ('fa-solid fa-pause')
      // buttonPlay.classList.remove('')
    });
  }


  Play() {
    const buttonPause = document.getElementById('ion-pause');

    buttonPause?.addEventListener('click', () => {
      buttonPause.id = 'ion-play'
      buttonPause.className = ('fa-regular fa-circle-play')
      // buttonPlay.classList.remove('')
    });
  }
}
